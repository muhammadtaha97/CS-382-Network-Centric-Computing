import socket
from _thread import *
import threading
import sys



#Recieving and sending messages to each and every client and rmoving client on special message
def threaded_client(client):
    print ("Accepted connection from client") 
    try:
        while True:
            data = client.recv(1024)

            if not data: 
                break
            from_client = data.decode("utf-8")
            if ':' not in from_client:
                connection.remove(client)
                print("connection closed")
            else:
                print(from_client)
                for conn in connection:
                    conn.send(data)
    finally:
        return




# Initializing the variables
ip_addr = sys.argv[1] 
port = sys.argv[2] 
total_clients = int(sys.argv[3])
counter = 0 
connection = []


#Making socket, binding and listening for connections to make with clients
serv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serv.bind((ip_addr, int(port)))
serv.listen(total_clients)
print("Waiting for a connection")



# Accepting connections and sending client numbers and total clients to 
# each client and running threaded clients on accepting all the required connections
while True:
    conn, addr = serv.accept()
    connection.append(conn)
    msg = str(total_clients)
    conn.sendall(msg.encode())
    counter = counter + 1
    if counter == total_clients:
        for i in range(total_clients):
            r_msg = str(i)
            connection[i].sendall(r_msg.encode())
        for i in range(total_clients):
            start_new_thread(threaded_client, (connection[i],))
   

          







   